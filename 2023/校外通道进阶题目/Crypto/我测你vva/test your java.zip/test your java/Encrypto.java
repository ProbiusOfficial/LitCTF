public class Encrypto{
    public static void main(String[] args) {
        String flag="";
        int cipher;
        char[] arr;
        arr=flag.toCharArray();
        for(int i=0; i<flag.length(); i++) {
           if(i%2==0){
            cipher=Integer.valueOf(arr[i]);
            cipher=cipher+i;
            System.out.print((char)cipher);
           }
           if(i%2!=0){
            cipher=Integer.valueOf(arr[i]);
            cipher=cipher-i;
            System.out.print((char)cipher);
           }
        }
    }
}
//cipher=HYEQJvPZ~X@+Bp